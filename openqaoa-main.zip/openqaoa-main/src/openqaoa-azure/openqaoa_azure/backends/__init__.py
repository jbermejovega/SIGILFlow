from .devices import DeviceAzure
